% clc; clear variables; 
close all; fclose('all'); delete('*.log','*.bak'); % dbstop if error; dbclear if error;
warning('off','all'); %warning
%%%%%%%%%%%%%%
%[CodeFolder,SheetName,DataFolder]=CodeFolder_SheetName_DataFolder_v01;  % Locations of the code and data folders. Sheet name of the runme.xlsx file
[CodeFolder,SheetName,DataFolder,~]=CodeFolder_SheetName_DataFolder_AlgName_v02;  % Locations of the code and data folders. Sheet name of the runme.xlsx file
fname=dir('*Runme*.xlsx');
x=xlsread(fname.name,SheetName,'A1:A200');
C=xlsread(fname.name,SheetName,['A1:A2' num2str(length(x))]);
CCell = num2cell(C);

[MonteCarlo, L, K, M, PdBTxRx, Init, Iter, GTS, sigma2n]=CCell{:};

Name1=sprintf('L%dK%dM%d',L,K,M); 
Name1x=sprintf('_MC%d',MonteCarlo);
Name1x=[Name1 Name1x];
Name2=['T' mat2str(PdBTxRx) '_In' mat2str(Init) '_I' mat2str(Iter) '_G' mat2str(GTS)]; 

% Checking the input files
InputFolder=InputFolder_v01(MonteCarlo,L,K,Name1,DataFolder);
[status,list]=system(InputFolder); 
if status==1
    disp('The input files are missing. They are now being generated. Please wait.')
    %pause(3);
    TempFolder=[DataFolder 'Temp\' Name1x '\' ]; 
    mkdir(TempFolder)
    copyfile(fname.name,TempFolder);
    [~,list]=system('dir G*.m /b');
    runner=textscan(list, '%s %s', 'delimiter','.');    
    copyfile([char(runner{1}) '.m'],TempFolder);
    cd(TempFolder)
    fidotemp = fopen('code_0X.log','w');
    fprintf(fidotemp,SheetName); fclose(fidotemp);
    run(char(runner{1}))  
    copyfile('Inputs',[DataFolder 'Inputs\'])
    cd ..
    rmdir(Name1x,'s')  
end
cd(CodeFolder)
%%
% The random channel and beamforming vector input files are copied to the current directory 
copyfile(InputFolder,pwd);
unzip(InputFolder);
delete('*.zip');
%%

%BIaII_v09a(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-                        (Selected)
%%BIaII_v08at4c(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter          (Selected)
%BIaII_v08at4d(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-BCCInit (Selected)
%BIaII_v08at3d(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-Mrf       (Selected)
%BIaII_v08at3e(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-SMrf       (Selected)
%BIaIII_v08c(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-BCC                    (Selected)
BIaIII_v10at04(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-BCC     (Selected) - Almost same with BIaIII_v06at3, but use this one 
%BIaIII_v10at01tBCC(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   %Multi-J-Init-Iter-BCC (Test)
%BIaIII_v10at02(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-BCC     (Test)
%BIaIII_v10at01t2(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-BCC     (On the fly)
%BIaIII_v10bt01(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-Mrf-BCC  (Selected)
%BIaIII_v10ct01(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-SMrf-BCC  (Selected)
%BIaIII_v11bt1(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-SEL-BCC  (Selected)
%BIaIII_v11bt1t(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-SEL-BCC  (On the fly)
%BIcI_v08a(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-DL                      (Selected)
%BIcI_v08as(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-DL-SEL                 (Selected)
%BIcII_v04a(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-DL-BCC                 (Selected)
%BIcII_v04d(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-DL-J-Init-Iter-BCC      (Selected)
%BIcI_v08b(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-SDL                      (Selected) 
%BIcV_v05b(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-SDL-BCC                 (Selected) 
%BIcV_v05bt(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-SDL-BCC                 (On the fly) 
%BIcV_v03bt5(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-SDL-J-Init-Iter-BCC   (Selected) 
%BIcV_v05bt6(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-TSDL-J-Init-Iter-BCC   (Selected) (True SDL-no rate evaluation at all)
%BIcV_v05bt6t(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-TSDL-J-Init-Iter-BCC   (On the fly) 
%BIcVI_v02b(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-SDL-SEL-BCC            (Selected) 
%BIfIc_v08(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)  % Multi-EXD2I                      (Selected)
%BIfII_v04(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)  % Multi-EXD2I-BCC                 (Selected) (Search segment: All transmitters and a user) (Requires M=L*K antennas)
%BIfIVa_v02(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)  % Multi-EXD2II                   (Selected) (Search segment: A transmitter and all users)
%BIfIIIa_v06a(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)  % Multi-EXD2II-BCC             (Selected) (Search segment: A transmitter and all users)
%BIfIIIa_v07e(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)  % Multi-EXD2II-J-Init-Iter-BCC (Selected) (Search segment: A transmitter and all users)
%BIfIIIa_v07et(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)  % Multi-EXD2II-J-Init-Iter-BCC (On the fly)