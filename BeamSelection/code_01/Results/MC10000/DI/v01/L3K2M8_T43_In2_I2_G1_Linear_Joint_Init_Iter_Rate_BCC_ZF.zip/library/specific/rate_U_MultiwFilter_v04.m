function [rate_U,rn,cn]=rate_U_MultiwFilter_v04(sP,l,K,M,H,Us,~)
epsilon=1e-6;
rate_U=zeros(K,1);               % sum of individual user rates per channel use
Heff=zeros(K);
Usx=Us(:,l*K+1:l*K+K);
for k=0:K-1
    Heff(k+1,:)=H(k*M+1:k*M+M,l+1)'*Usx;
end
HeffH=Heff';
%V(:,l*K+1:l*K+K)=HeffH/(HeffH*Heff);  % This is wrong
V=HeffH/(Heff*HeffH); % This is wright
xx=eig(Heff*HeffH);
%ei(l+1)=sum(xx);
rn=K-sum(find(xx<=epsilon));
a=find(sign(xx)==-1);    % replacing - eigen values with epsilon
xx(a)=epsilon*ones(length(a),1);
cn=max(xx)/min(xx);

%     % With the right version above, you may not need this if check. Control it and erase if not
%     % necessary
%     if sum(sum(abs(V(:,l*K+1:l*K+K))==Inf)) || sum(sum(abs(V(:,l*K+1:l*K+K))==0))
%         for k=0:K-1
%             Heff(k+1,:)=H(k*M+1:k*M+M,l+1)'*Usx(:,k+1);
%             V(:,l*K+k+1)=Heff(k+1,:)';
%             cc=1
%         end
%     end

for k=0:K-1
    %V(:,l*K+k+1)=V(:,l*K+k+1)/norm(V(:,l*K+k+1))*sqrt(K);   % Normalized power (equal power allocation)
    %V(:,l*K+k+1)=V(:,l*K+k+1)/norm(V(:,l*K+k+1));   % Normalized power (equal power allocation) - My approach. Although this approach gives V with higher power, sum-rate is lower. Probably, unnecessary power is causing interference
    V(:,k+1)=V(:,k+1)/norm(Usx*V(:,k+1),'fro');   % Normalized power (equal power allocation) due to beam conflict. See BeamSelection_v02.docx, BeamTrainingandAllocation...pdf
    %norm(Usx*Vx(:,l*K+1),'fro')^2       % Must be equal to 1
    %         xx=round(norm(Usx*V(:,l*K+1),'fro')^2);    % Must be equal to 1
    %         if xx~=1
    %             xx
    %         end
end
%norm(Usx*Vx(:,l*K+1:l*K+K),'fro')^2 % Must be equal to K
%yy=round(norm(Usx*V(:,l*K+1:l*K+K),'fro')^2); % Must be equal to K
%     if yy~=K
%         yy
%     end


for k=0:K-1
    Heff=H(k*M+1:k*M+M,l+1)'*Usx;
    num=sP(l*K+k+1)*(Heff*V(:,k+1));
    num=abs(num)^2;
    rate_U(k+1)=num;
end