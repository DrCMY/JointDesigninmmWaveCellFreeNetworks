function coh=coh_v01(UoptsM,L,K)
coh=0;
for k=0:K-1
    cohx=L-length(unique(UoptsM(k+1:K:L*K)))+1;
    if cohx==1
       cohx=0;
    end
    coh=coh+cohx;    
end
coh=coh/(L*K);