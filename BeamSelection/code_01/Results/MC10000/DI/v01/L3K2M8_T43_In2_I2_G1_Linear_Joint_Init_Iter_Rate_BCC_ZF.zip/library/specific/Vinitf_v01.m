function V=Vinitf_v01(Us,L,K)
Mean=0;                        % Mean of the channel
SqrtVarpD=sqrt(.5);            % Variance of the channel per dimension
B=L*K;
V=normrnd(Mean,SqrtVarpD,K,B)+1j*normrnd(Mean,SqrtVarpD,K,B);
%load V
for l=0:L-1
    Usx=Us(:,l*K+1:l*K+K);
    for k=0:K-1
        V(:,l*K+k+1)=V(:,l*K+k+1)/norm(Usx*V(:,l*K+k+1),'fro');   % Normalized power (equal power allocation) due to beam conflict. See BeamSelection_v02.docx, BeamTrainingandAllocation...pdf
    end
end