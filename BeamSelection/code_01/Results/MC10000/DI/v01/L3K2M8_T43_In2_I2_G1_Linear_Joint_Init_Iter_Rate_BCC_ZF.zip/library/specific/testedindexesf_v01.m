function testedindexes=testedindexesf_v01(Us,U)
[~,length]=size(Us);
testedindexes=zeros(1,length);
for l=1:length
    [~,~,testedindexes(1,l)]=intersect(Us(:,l).',U.','rows');
end