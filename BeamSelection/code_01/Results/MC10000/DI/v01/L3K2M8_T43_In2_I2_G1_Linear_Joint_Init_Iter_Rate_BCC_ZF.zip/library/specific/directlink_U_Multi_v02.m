function rate_U=directlink_U_Multi_v02(sP,L,K,M,H,Us)
rate_U=zeros(K,1);               % sum of individual user rates per channel use
for k=0:K-1
    num=0;
    for l=0:L-1
        num=num+sP(l*K+k+1)*H(k*M+1:k*M+M,l+1)'*Us(:,l*K+k+1);
    end
    num=abs(num)^2;
    rate_U(k+1)=num;
end