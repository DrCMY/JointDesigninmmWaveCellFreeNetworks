function BIaIII_v08a(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)
tgGlobal=tic;
%AlgNameA='Multi_BCC';                 % Name of the algorithm
AlgNameB='ZF';                 % Name of the algorithm

[cverSubFile_a,cverSubFile_b]=CodeVersion_v01(mfilename);             % Calling subfunction to detect the version of the current code

[CodeFolder,~,~]=CodeFolder_SheetName_DataFolder_v01;  % Locations of the code and data folders. Sheet name of the runme.xlsx file
fname=dir('*NetworkList*.xlsx');
x=xlsread(fname.name,'AlgorithmsList_v01','C1:C25');
[~,FileName,~]=xlsread(fname.name,'AlgorithmsList_v01',['C1:C2' num2str(length(x))]);
x=xlsread(fname.name,'AlgorithmsList_v01','D1:C25');
[~,AlgNames,~]=xlsread(fname.name,'AlgorithmsList_v01',['D1:D2' num2str(length(x))]);
AlgNameAx=AlgNames(strcmp(mfilename,FileName));
AlgNameA=AlgNameAx{1};
cd(CodeFolder)

AlgName=[AlgNameA '_' AlgNameB];
disp(['Now ' AlgName ' is being executed'])

rate_MC=zeros(K,1);              % sum of individual user rates over Monte Carlo runs
rn_MC=zeros(1,L); 
cn_MC=zeros(1,L); 

[fi1,fi2,fi3,fido1,Name]=IOFiles_v02(Name1,Name2,cverSubFile_b);
fi2=replace(fi2,'_Us.log','_UsBCC.log');
Name=[Name '_' AlgName];
Complexity=Iter*L*K*M;
loaders=zeros(2,1);
mc=1;               % Monte Carlo counter
mM=(0:M-1);
U=(1/sqrt(M))*exp(-(1i*2*pi*(mM'*mM))/M);    % DFT matrix. Normalized so that ||U_l||_F^2=1 per AP
UoptsM=zeros(1,L*K);
converter=M.^(L*K-1:-1:0); % Uncomment for AI training&testing
indexvM=zeros(MonteCarlo,1);
% stepiM=zeros(MonteCarlo,1); % Uncomment for iteration control
while mc<=MonteCarlo 
    H=dlmread(fi1,'\t',[loaders(1) 0 loaders(1)+K*M-1 L-1]);        
    randindexes=dlmread(fi2,'\t',[loaders(2) 0 loaders(2) L*K-1]);     
    sP=dlmread(fi3,'\t',[loaders(2) 0 loaders(2) L*K-1]);   
    Us=U(:,randindexes);         % Randomly selected beamforming vectors
    loaders(1)=loaders(1)+K*M;
    loaders(2)=loaders(2)+1;
    % rate_Sum_max=0; % Uncomment for iteration control    
    for stepi=1:Iter
        mMUsers=repmat(mM,[K,1]);
        kcounter=M*ones(K,1);
        for l=0:L-1
            for k=0:K-1
                kx=kcounter(k+1);
                rate_O=zeros(kx,1);              
                for m=1:kx
                    Us(:,l*K+k+1)=U(:,mMUsers(k+1,m)+1);
                    rate_O(m)=sum(rate_U_MultiIa_v03(sP,L,K,M,H,Us,sigma2n));  % Calling the rate_U_Multi function
                end
                [~,index]=max(rate_O);
                indexx=mMUsers(k+1,index);
                kNot=(0:K-1)';
                kNot(k+1)=[];
                for kk=1:K-1
                    indexxx=find(mMUsers(kNot(kk)+1,:)==indexx);
                    if ~isempty(indexxx)
                        mMUsers(kNot(kk)+1,indexxx:end)=[mMUsers(kNot(kk)+1,indexxx+1:end) 0.1];
                        kcounter(kNot(kk)+1)=kcounter(kNot(kk)+1)-1;
                    end
                end                
                Us(:,l*K+k+1)=U(:,indexx+1);
                UoptsM(1,l*K+k+1)=indexx+1;
            end
        end
        %%%
        % Uncomment for iteration control
%         rate_Sum=sum(rate_U_Multi_v02(sP,L,K,M,H,Us,sigma2n)); % Calling the rate_U_Multi function
%         if rate_Sum>rate_Sum_max
%             rate_Sum_max=rate_Sum;
%             stepi_opt=stepi;
%         else
%             break
%         end
       %%%
    end
    % stepiM(mc)=stepi_opt; % Uncomment for iteration control
    indexvM(mc)=converter*(UoptsM-1)'; 
    if strcmp(AlgNameB,'ZF')
        [rate_U,rn,cn]=rate_U_MultiwFilter_v02dt1b(sP,L,K,M,H,Us,sigma2n); % Calling the rate_U_Multi function. ZF
    elseif strcmp(AlgNameB,'MMSE')
        [rate_U,rn,cn]=rate_U_MultiwFilter_v02dt2c(sP,L,K,M,H,Us,sigma2n); % Calling the rate_U_Multi function. MMSE
    elseif strcmp(AlgNameB,'NoFilter')
        [rate_U,rn,cn]=rate_U_MultiII_v01(sP,L,K,M,H,Us,sigma2n);          % Calling the rate_U_Multi function. No filter        
    end    
    rate_MC=rate_MC+rate_U;
    rn_MC=rn_MC+rn; 
    cn_MC=cn_MC+cn; 
    mc=mc+1;
end
% For iteration control:
% Outputs_Multi_v06(MonteCarlo,L,K,M,PdBTxRx,mean(stepiM),GTS,fido1,AlgName,Name,Name1,cverSubFile_a,cverSubFile_b,tgGlobal,Complexity,InputFolder,rate_MC,indexvM)
Outputs_Multi_v09(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,fido1,AlgName,Name,Name1,cverSubFile_a,cverSubFile_b,tgGlobal,Complexity,InputFolder,rate_MC,indexvM,rn_MC,cn_MC)