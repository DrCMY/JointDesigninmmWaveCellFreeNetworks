% clc; clear variables; 
close all; fclose('all'); delete('*.log','*.bak'); % dbstop if error; dbclear if error;
warning('off','all'); %warning
%%%%%%%%%%%%%%
[CodeFolder,SheetName,DataFolder]=CodeFolder_SheetName_DataFolder_v01;  % Locations of the code and data folders. Sheet name of the runme.xlsx file
fname=dir('*Runme*.xlsx');
x=xlsread(fname.name,SheetName,'A1:A200');
C=xlsread(fname.name,SheetName,['A1:A2' num2str(length(x))]);
CCell = num2cell(C);

[MonteCarlo, L, K, M, PdBTxRx, Init, Iter, GTS, sigma2n]=CCell{:};

Name1=sprintf('L%dK%dM%d',L,K,M); 
Name2=['T' mat2str(PdBTxRx) '_In' mat2str(Init) '_I' mat2str(Iter) '_G' mat2str(GTS)]; 

% Checking the input files
InputFolder=InputFolder_v01(MonteCarlo,L,K,Name1,DataFolder);
[status,list]=system(InputFolder); 
if status==1
    disp('The input files are missing. They are now being generated. Please wait.')
    %pause(3);
    TempFolder=[DataFolder 'Temp\' Name1 '\' ]; 
    mkdir(TempFolder)
    copyfile(fname.name,TempFolder);
    [~,list]=system('dir G*.m /b');
    runner=textscan(list, '%s %s', 'delimiter','.');    
    copyfile([char(runner{1}) '.m'],TempFolder);
    cd(TempFolder)
    fidotemp = fopen('code_0X.log','w');
    fprintf(fidotemp,SheetName); fclose(fidotemp);
    run(char(runner{1}))  
    copyfile('Inputs',[DataFolder 'Inputs\'])
    cd ..
    rmdir(Name1,'s')  
end
cd(CodeFolder)
%%
% The random channel and beamforming vector input files are copied to the current directory 
copyfile(InputFolder,pwd);
unzip(InputFolder);
delete('*.zip');
%%

%BIaII_v09a(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-                        (Selected)
%BIaII_v08at3(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init                (Selected)
%BIaIII_v08a(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-BCC                    (Selected)
BIaIII_v08at01(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-BCC     (Selected) - Almost same with BIaIII_v06at3, but use this one 
%BIaIII_v09bt1(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)   % Multi-J-Init-Iter-BCC-SEL  (Selected)
%BIcI_v08a(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-DL                      (Selected)
%BIcI_v08as(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-DL-SEL                 (Selected)
%BIcII_v04a(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-DL-BCC                 (Selected)
%BIcII_v04d(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-DL-J-Init-Iter-BCC      (Selected)
%BIcI_v08b(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-SDL                      (Selected) 
%BIcV_v03b(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-SDL-BCC                 (Selected) 
%BIcV_v03bt5(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-SDL-J-Init-Iter-BCC   (Selected) 
%BIcVI_v02b(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)    % Multi-SDL-BCC-SEL            (Selected) 
%BIfIc_v08(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)  % Multi-EXD2I                      (Selected)
%BIfII_v04(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)  % Multi-EXD2I-BCC                 (Selected) (Search segment: All transmitters and a user) (Requires M=L*K antennas)
%BIfIVa_v02(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)  % Multi-EXD2II                   (Selected) (Search segment: A transmitter and all users)
%BIfIIIa_v06a(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)  % Multi-EXD2II-BCC             (Selected) (Search segment: A transmitter and all users)
%BIfIIIa_v06e(MonteCarlo,L,K,M,PdBTxRx,Init,Iter,GTS,sigma2n,Name1,Name2,InputFolder)  % Multi-EXD2II-J-Init-Iter-BCC (Selected) (Search segment: A transmitter and all users)